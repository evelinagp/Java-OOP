package PolymorphismMathOperationLab01;

public class MathOperation {

    public int add(int first, int second) {
        return first + second;
    }

    public int add(int first, int second, int third) {
        return first + second + third;
    }

    public int add(int first, int second, int third, int fourth) {
        return first + second + third + fourth;
    }
}
