package PolymorphismVehiclesExtensionEx02;

public interface VehicleImpl {

    String drive(double distance);
    void refuel(double liters);
}
