package InterfacesAndAbstarctionSayHelloExtendedLab04;

public class Chinese extends BasePerson {
    public Chinese(String name) {
        super(name);
    }

    public String sayHello(){
        return "Djydjybydjy";
    }
}
