package InterfacesAndAbstarctionFerrariLab06;

public interface Car {
    String brakes();
    String gas();
}
