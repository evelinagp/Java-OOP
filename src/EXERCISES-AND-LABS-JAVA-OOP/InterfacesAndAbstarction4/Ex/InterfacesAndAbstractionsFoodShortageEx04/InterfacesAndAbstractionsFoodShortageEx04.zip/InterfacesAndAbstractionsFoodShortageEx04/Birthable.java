package InterfacesAndAbstractionsFoodShortageEx04;

public interface Birthable {
    String getBirthDate();
}
