package InterfacesAndAbstractionsFoodShortageEx04;

public interface Identifiable {
    String getId();
}
