package InterfacesAndAbstractionsBirthdayCelebrationsEx03;

public interface Creature {
    String getName();

}
