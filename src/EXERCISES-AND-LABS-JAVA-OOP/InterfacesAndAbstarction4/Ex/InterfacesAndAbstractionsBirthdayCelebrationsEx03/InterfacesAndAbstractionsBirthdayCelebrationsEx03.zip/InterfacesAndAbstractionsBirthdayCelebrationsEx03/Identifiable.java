package InterfacesAndAbstractionsBirthdayCelebrationsEx03;

public interface Identifiable {
    String getId();
}
