package InterfacesAndAbstractionsBirthdayCelebrationsEx03;

public interface Machine {
    String getModel();
}
