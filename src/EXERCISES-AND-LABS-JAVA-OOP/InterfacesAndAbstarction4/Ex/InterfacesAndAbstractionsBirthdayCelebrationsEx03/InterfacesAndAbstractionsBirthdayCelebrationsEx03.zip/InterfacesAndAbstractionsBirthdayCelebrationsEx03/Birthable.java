package InterfacesAndAbstractionsBirthdayCelebrationsEx03;

public interface Birthable {
    String getBirthDate();
}
