package InterfacesAndAbstractionsTelephonyEx05;

public interface Callable {
    String call();
}
