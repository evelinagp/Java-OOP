package InterfacesAndAbstarctionProblemMultipleImplementationEx02;

public interface Identifiable {
    String getId();
}
