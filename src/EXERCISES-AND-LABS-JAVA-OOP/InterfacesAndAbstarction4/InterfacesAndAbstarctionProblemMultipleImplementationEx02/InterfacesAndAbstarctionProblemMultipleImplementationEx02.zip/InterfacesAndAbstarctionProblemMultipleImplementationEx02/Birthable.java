package InterfacesAndAbstarctionProblemMultipleImplementationEx02;

public interface Birthable {
    String getBirthDate();
}
