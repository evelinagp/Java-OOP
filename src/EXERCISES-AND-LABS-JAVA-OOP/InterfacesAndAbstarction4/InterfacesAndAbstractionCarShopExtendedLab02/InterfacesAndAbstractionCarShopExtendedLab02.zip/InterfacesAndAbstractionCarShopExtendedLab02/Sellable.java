package InterfacesAndAbstractionCarShopExtendedLab02;

public interface Sellable {
    Double getPrice();
}
