package InterfacesAndAbstractionCarShopExtendedLab02;

public interface Rentable {
//+getMinRentDay(): Integer
    Integer getMinRentDay();
//+getPricePerDay(): Double
    Double getPricePerDay();
}
