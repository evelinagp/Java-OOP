package InterfacesAndAbstractionsCollectionHierarchyEx07;

public interface Addable {
    int add(String item);
}
