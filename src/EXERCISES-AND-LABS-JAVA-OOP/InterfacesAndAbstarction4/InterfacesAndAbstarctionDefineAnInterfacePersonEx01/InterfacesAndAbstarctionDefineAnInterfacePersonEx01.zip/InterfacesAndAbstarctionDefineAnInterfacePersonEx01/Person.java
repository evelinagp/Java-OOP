package InterfacesAndAbstarctionDefineAnInterfacePersonEx01;

public interface Person {
    String getName();
    int getAge();

}
