package InterfacesAndAbstarctionBorderControlLab05;

public interface Identifiable {
    String getId ();
}
