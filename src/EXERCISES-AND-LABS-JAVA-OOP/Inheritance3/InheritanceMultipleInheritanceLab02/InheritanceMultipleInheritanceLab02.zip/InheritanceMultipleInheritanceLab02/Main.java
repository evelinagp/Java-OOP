package InheritanceMultipleInheritanceLab02;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Puppy puppy = new Puppy();
        puppy.eat();
        puppy.bark();
        puppy.weep();

    }
}
