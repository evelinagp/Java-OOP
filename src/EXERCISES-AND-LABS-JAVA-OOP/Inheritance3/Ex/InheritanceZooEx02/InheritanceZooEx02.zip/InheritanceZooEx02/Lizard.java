package InheritanceZooEx02;

public class Lizard extends Reptile {
    public Lizard(String name) {
        super(name);
    }
}
