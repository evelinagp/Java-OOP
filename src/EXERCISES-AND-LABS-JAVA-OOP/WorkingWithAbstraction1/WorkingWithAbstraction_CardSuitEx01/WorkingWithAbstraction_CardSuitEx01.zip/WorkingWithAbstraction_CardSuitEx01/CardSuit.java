package WorkingWithAbstraction_CardSuitEx01;

public enum CardSuit {
    //    CLUBS, DIAMONDS, HEARTS, SPADES
    CLUBS,  //СПАТИЯ
    DIAMONDS, // КАРО
    HEARTS, // КУПА
    SPADES; // ПИКА
}
