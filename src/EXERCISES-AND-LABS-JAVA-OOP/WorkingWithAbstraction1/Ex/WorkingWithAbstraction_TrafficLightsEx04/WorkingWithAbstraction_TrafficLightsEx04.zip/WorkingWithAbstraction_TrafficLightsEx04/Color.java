package WorkingWithAbstraction_TrafficLightsEx04;

public enum Color {
    RED,
    GREEN,
    YELLOW;

}
