package input;

public class ConsolePrinter {
    public static void printLine (String string){
        System.out.println(string);
    }
}
